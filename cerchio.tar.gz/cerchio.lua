-- Script Lua definitivo per anello orario fluido tramite lettura /proc/uptime
require 'cairo'
require 'cairo_xlib'

function rgb_to_r_g_b(color, alpha)
    return ((color / 0x10000) % 0x100) / 255., ((color / 0x100) % 0x100) / 255., (color % 0x100) / 255., alpha
end

function draw_ring(cr, xc, yc, radius, thickness, start_angle, end_angle, color, alpha)
    cairo_set_source_rgba(cr, rgb_to_r_g_b(color, alpha))
    cairo_set_line_width(cr, thickness)
    cairo_arc(cr, xc, yc, radius, start_angle * math.pi / 180 - math.pi / 2, end_angle * math.pi / 180 - math.pi / 2)
    cairo_stroke(cr)
end

-- Funzione globale per passare i dati calcolati al testo di Conky
function conky_get_uptime_data(mode)
    local file = io.open("/proc/uptime", "r")
    if not file then return "0" end
    local total_seconds = math.floor(tonumber(string.match(file:read("*l"), "^([%d%.]+)")) or 0)
    file:close()

    if mode == "hours" then
        return tostring(math.floor(total_seconds / 3600))
    elseif mode == "minutes" then
        return tostring(math.floor((total_seconds % 3600) / 60))
    elseif mode == "seconds" then
        return tostring(total_seconds % 60)
    end
    return "0"
end

function conky_main()
    if conky_window == nil then return end
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)
    
    -- Dimensioni dell'anello
    local xc, yc, radius, thickness = 100, 100, 70, 5
    
    -- Legge i secondi reali dal sistema Linux
    local file = io.open("/proc/uptime", "r")
    if file then
        local uptime_line = file:read("*l")
        file:close()
        local total_seconds = tonumber(string.match(uptime_line, "^([%d%.]+)")) or 0
        
        -- Calcola i secondi passati nell'ora corrente (0-3599)
        local seconds_in_current_hour = total_seconds % 3600
        local percentage = seconds_in_current_hour / 3600
        local end_angle = percentage * 360
        
        if end_angle == 0 then end_angle = 0.1 end
        
        -- Sfondo grigio dell'anello
        draw_ring(cr, xc, yc, radius, thickness, 0, 360, 0x333333, 0.4)
        -- Progresso azzurro fluido dell'anello
        draw_ring(cr, xc, yc, radius, thickness, 0, end_angle, 0x00bfff, 0.9)
    end
    
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end
