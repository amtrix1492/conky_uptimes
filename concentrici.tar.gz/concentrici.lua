require 'cairo'
require 'cairo_xlib'
-- Configurazione dei 3 cerchi concentrici spostati più in alto (y=100)
settings_table = {
    {
        -- Cerchio ESTERNO: Secondi
        type='seconds',
        max=60,
        x=150,
        y=100,
        radius=80,
        thickness=5,
        bg_colour=0xffffff,
        bg_alpha=0.15,
        fg_colour=0xff0000,
        fg_alpha=0.8,
        font_size=14
    },
    {
        -- Cerchio INTERMEDIO: Minuti
        type='minutes',
        max=60,
        x=150,
        y=100,
        radius=55,
        thickness=5,
        bg_colour=0xffffff,
        bg_alpha=0.15,
        fg_colour=0x00ff00,
        fg_alpha=0.8,
        font_size=12
    },
    {
        -- Cerchio INTERNO: Ore/Cicli
        type='hours',
        max=24,
        x=150,
        y=100,
        radius=30,
        thickness=5,
        bg_colour=0xffffff,
        bg_alpha=0.15,
        fg_colour=0x0000ff,
        fg_alpha=0.8,
        font_size=11
    }
}

function get_system_uptime()
    local file = io.open("/proc/uptime", "r")
    if file then
        local content = file:read("*all")
        file:close()
        local uptime_seconds = tonumber(string.match(content, "^%d+%.?%d*"))
        return uptime_seconds or 0
    end
    return 0
end

function draw_text_in_ring(cr, target_ring)
    cairo_save(cr)

    local uptime_seconds = get_system_uptime()
    local text = ""
    
    if target_ring.type == 'seconds' then
        text = tostring(math.floor(uptime_seconds % 60))
    elseif target_ring.type == 'minutes' then
        text = tostring(math.floor((uptime_seconds / 60) % 60))
    elseif target_ring.type == 'hours' then
        text = tostring(math.floor(uptime_seconds / 3600))
    end
    
    cairo_select_font_face(cr, "DejaVu Sans Mono", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD)
    cairo_set_font_size(cr, target_ring.font_size)
    
    cairo_set_source_rgba(cr, 
        ((target_ring.fg_colour / 0x10000) % 0x100) / 255, 
        ((target_ring.fg_colour / 0x100) % 0x100) / 255, 
        (target_ring.fg_colour % 0x100) / 255, 
        target_ring.fg_alpha
    )
    
    local extents = cairo_text_extents_t:create()
    cairo_text_extents(cr, text, extents)
    
    local text_x = target_ring.x + target_ring.radius + 6 - extents.x_bearing
    local text_y = target_ring.y - (extents.height / 2) - extents.y_bearing
    
    cairo_move_to(cr, text_x, text_y)
    cairo_show_text(cr, text)
    cairo_stroke(cr)
    
    cairo_restore(cr)
end

function draw_ring(cr, t)
    cairo_save(cr)

    local uptime_seconds = get_system_uptime()
    local pct = 0

    if t.type == 'seconds' then
        pct = (math.sin((uptime_seconds * math.pi / t.max) - (math.pi / 2)) + 1) / 2
    elseif t.type == 'minutes' then
        local total_minutes = uptime_seconds / 60
        pct = (math.sin((total_minutes * math.pi / t.max) - (math.pi / 2)) + 1) / 2
    elseif t.type == 'hours' then
        local total_hours = uptime_seconds / 3600
        pct = (math.sin((total_hours * math.pi / t.max) - (math.pi / 2)) + 1) / 2
    end

    local angle_0 = -math.pi / 2
    local angle_f = angle_0 + (pct * 2 * math.pi)

    cairo_set_source_rgba(cr, ((t.bg_colour / 0x10000) % 0x100) / 255, ((t.bg_colour / 0x100) % 0x100) / 255, (t.bg_colour % 0x100) / 255, t.bg_alpha)
    cairo_set_line_width(cr, t.thickness)
    cairo_arc(cr, t.x, t.y, t.radius, 0, 2 * math.pi)
    cairo_stroke(cr)

    if pct > 0 then
        cairo_set_source_rgba(cr, ((t.fg_colour / 0x10000) % 0x100) / 255, ((t.fg_colour / 0x100) % 0x100) / 255, (t.fg_colour % 0x100) / 255, t.fg_alpha)
        cairo_set_line_width(cr, t.thickness)
        cairo_arc(cr, t.x, t.y, t.radius, angle_0, angle_f)
        cairo_stroke(cr)
    end

    cairo_restore(cr)
end

function conky_main()
    if conky_window == nil then return end
    local cs = cairo_xlib_surface_create(conky_window.display, conky_window.drawable, conky_window.visual, conky_window.width, conky_window.height)
    local cr = cairo_create(cs)
    
    local updates = conky_parse('${updates}')
    local update_num = tonumber(updates)
    
    if update_num > 5 then
        for i in pairs(settings_table) do
            draw_ring(cr, settings_table[i])
            draw_text_in_ring(cr, settings_table[i])
        end
    end
    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end
